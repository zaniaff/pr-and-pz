﻿using System;
using System.Collections.Generic;
using System.Text;

namespace war_2
{
    public class Monster
    {
        public int hp = Convert.ToInt32(Console.ReadLine());

        

        public int power = Convert.ToInt32(Console.ReadLine());
    }
}
