﻿using System;

namespace war_2
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            
            Console.WriteLine("введите первое значение - здоровье монстра");
            Console.WriteLine("введите второе значение - сила монстра");
           
           
            Monster monster = new Monster();
            int sum = monster.hp + monster.power;
            int basicHP = 100;
            int basicPower = 50;

            if (sum < 150 && sum > 2)
            {

                if (monster.hp < 101 && monster.power < 101 && monster.hp > 1 && monster.power > 1)
                {
                    Console.WriteLine("здоровье: {0} ",monster.hp);
                    Console.WriteLine("сила: {0}", monster.power);
                }
                else
                {
                    Console.WriteLine("превышен лимит или меньше требуемого, базовое здоровье: {0} ",basicHP );
                    Console.WriteLine("превышен лимит или меньше требуемого, базовая сила: {0}", basicPower);
                }

            
            }
            else
            {
                Console.WriteLine("превышен лимит или меньше требуемого, базовое здоровье: {0} ", basicHP);
                Console.WriteLine("превышен лимит или меньше требуемого, базовая сила: {0}", basicPower);
            }


        }
    }
}
