﻿using System;
using System.Collections.Generic;
using System.Text;

namespace war
{
    public class Monster
    {
       public int hp = 100;
       public int power = 200;

        
    }
}
