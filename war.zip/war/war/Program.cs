﻿using System;

namespace war
{
    public class Program
    {



        static void Main(string[] args)
        {
            Monster monster = new Monster();
            Human human = new Human();


            Console.WriteLine("здоровье монстра: {0},  сила монстра: {1}", monster.hp, monster.power   );

            Console.WriteLine("части тела человека в которые может наносить удары: {0} , {1} , {2} , {3}",human.head,human.tors,human.heands,human.legs );
        }


    }
}
