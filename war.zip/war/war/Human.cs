﻿using System;
using System.Collections.Generic;
using System.Text;

namespace war
{
    public class Human
    {
        public string head = "голова";
        public string tors = "тело";
        public string heands = "рука";
        public string legs = "нога";
    }
}
